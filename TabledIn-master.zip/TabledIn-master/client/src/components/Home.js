import React from 'react'

const Home = () => {
  return (
    <React.Fragment>
      <h3>Welcome to your restaurant!</h3>
    </React.Fragment>
  )
}

export default Home
